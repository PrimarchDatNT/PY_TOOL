local config = {}

-- 模糊宽高系数: 默认值480，越大越不模糊。ps:最好为4的倍数，我这里先改成960。
config.blurBaseDefault = 1680

-- 模糊程度: 默认1
config.blurLevelDefault = 1

-- 模糊不透明度: 默认90
config.blurDegreeDefault = 80

return config