#ifdef GL_ES
precision highp  float;
#else
#define highp
#define mediump
#define lowp
#endif

varying vec2 mt_index;//sucai
varying vec2 mt_CameraIndex;//src
uniform sampler2D inputImageTexture0;

uniform sampler2D inputImageTexture1;
uniform sampler2D inputImageTexture2;
uniform sampler2D inputImageTexture3;
uniform sampler2D inputImageTexture4;
uniform sampler2D inputImageTexture5;

uniform float alpha;

vec4 lut3d(highp vec4 textureColor)
{
    float blueColor = textureColor.b * 15.0;
    vec2 quad1;
    quad1.y = max(min(4.0,floor(floor(blueColor) / 4.0)),0.0);
    quad1.x = max(min(4.0,floor(blueColor) - (quad1.y * 4.0)),0.0);
    
    vec2 quad2;
    quad2.y = max(min(floor(ceil(blueColor) / 4.0),4.0),0.0);
    quad2.x = max(min(ceil(blueColor) - (quad2.y * 4.0),4.0),0.0);
    
    vec2 texPos1;
    texPos1.x = (quad1.x * 0.25) + 0.5/64.0 + ((0.25 - 1.0/64.0) * textureColor.r);
    texPos1.y = (quad1.y * 0.25) + 0.5/64.0 + ((0.25 - 1.0/64.0) * textureColor.g);
    
    vec2 texPos2;
    texPos2.x = (quad2.x * 0.25) + 0.5/64.0 + ((0.25 - 1.0/64.0) * textureColor.r);
    texPos2.y = (quad2.y * 0.25) + 0.5/64.0 + ((0.25 - 1.0/64.0) * textureColor.g);
    
    vec4 newColor1 = texture2D(inputImageTexture1, texPos1);
    vec4 newColor2 = texture2D(inputImageTexture1, texPos2);
    vec4 newColor = mix(newColor1, newColor2, fract(blueColor));
    return newColor;
}
void main()
{
    vec4 orgColor =texture2D(inputImageTexture0, mt_CameraIndex);
    vec4 tempColor = orgColor;
    tempColor = lut3d(tempColor);
    vec4 temp = texture2D(inputImageTexture2, mt_index);
    temp.r=temp.r/temp.a;
    temp.g=temp.g/temp.a;
    temp.b=temp.b/temp.a;
    tempColor.r = mix(tempColor.r,texture2D( inputImageTexture3, vec2(temp.r,tempColor.r)).r, temp.a);
    tempColor.g = mix(tempColor.g,texture2D( inputImageTexture3, vec2(temp.g,tempColor.g)).g, temp.a);
    tempColor.b = mix(tempColor.b,texture2D( inputImageTexture3, vec2(temp.b,tempColor.b)).b, temp.a);
    
    temp = texture2D(inputImageTexture4, mt_index);
    
    tempColor.r = mix(tempColor.r,texture2D( inputImageTexture5, vec2(temp.r,tempColor.r)).r, temp.a);
    tempColor.g = mix(tempColor.g,texture2D( inputImageTexture5, vec2(temp.g,tempColor.g)).g, temp.a);
    tempColor.b = mix(tempColor.b,texture2D( inputImageTexture5, vec2(temp.b,tempColor.b)).b, temp.a);
    
    gl_FragColor = vec4(mix(orgColor.rgb,tempColor.rgb,alpha),1.0);
    
}
