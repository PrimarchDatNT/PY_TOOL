#ifdef GL_ES//for discriminate GLES & GL
#ifdef GL_FRAGMENT_PRECISION_HIGH
precision highp float;
#else
precision mediump float;
#endif
#else
#define highp
#define mediump
#define lowp
#endif

uniform sampler2D inputImageTexture0;
uniform sampler2D inputImageTexture1;
uniform sampler2D inputImageTexture2;
uniform sampler2D inputImageTexture3;
uniform sampler2D inputImageTexture4;
uniform sampler2D inputImageTexture5;
uniform sampler2D inputImageTexture6;
uniform sampler2D inputImageTexture7;
uniform sampler2D inputImageTexture8;

varying vec2 texcoordOut;
varying vec2 texcoordOut2;
//uniform float alpha;

lowp vec4 lut3d(highp vec4 textureColor)
{
    mediump float blueColor = textureColor.b * 15.0;
    mediump vec2 quad1;
    quad1.y = max(min(4.0,floor(floor(blueColor) * 0.25)),0.0);
    quad1.x = max(min(4.0,floor(blueColor) - (quad1.y * 4.0)),0.0);
    
    mediump vec2 quad2;
    quad2.y = max(min(floor(ceil(blueColor) * 0.25),4.0),0.0);
    quad2.x = max(min(ceil(blueColor) - (quad2.y * 4.0),4.0),0.0);
    
    highp vec2 texPos1;
    texPos1.x = (quad1.x * 0.25) + 0.0078125 + ((0.234375) * textureColor.r);
    texPos1.y = (quad1.y * 0.25) + 0.0078125 + ((0.234375) * textureColor.g);
    
    highp vec2 texPos2;
    texPos2.x = (quad2.x * 0.25) + 0.0078125 + ((0.234375) * textureColor.r);
    texPos2.y = (quad2.y * 0.25) + 0.0078125 + ((0.234375) * textureColor.g);
    
    lowp vec4 newColor1 = texture2D(inputImageTexture1, texPos1);
    lowp vec4 newColor2 = texture2D(inputImageTexture1, texPos2);
    
    mediump vec4 newColor = mix(newColor1, newColor2, fract(blueColor));
    
    return newColor;
}

void main()
{
    vec4 orgColor = texture2D(inputImageTexture0, texcoordOut);
    vec4 srcColor = orgColor;
    vec4 tempColor = lut3d(orgColor);
    
    vec4 temp = texture2D(inputImageTexture2, texcoordOut2);
    temp.r=temp.r/temp.a;
    temp.g=temp.g/temp.a;
    temp.b=temp.b/temp.a;
    tempColor.r = mix(tempColor.r,texture2D( inputImageTexture3, vec2(temp.r,tempColor.r)).r, temp.a);
    tempColor.g = mix(tempColor.g,texture2D( inputImageTexture3, vec2(temp.g,tempColor.g)).g, temp.a);
    tempColor.b = mix(tempColor.b,texture2D( inputImageTexture3, vec2(temp.b,tempColor.b)).b, temp.a);

    temp = texture2D(inputImageTexture4, texcoordOut2);
    temp.r=temp.r/temp.a;
    temp.g=temp.g/temp.a;
    temp.b=temp.b/temp.a;
    tempColor.r = mix(tempColor.r,texture2D( inputImageTexture5, vec2(temp.r,tempColor.r)).r, temp.a);
    tempColor.g = mix(tempColor.g,texture2D( inputImageTexture5, vec2(temp.g,tempColor.g)).g, temp.a);
    tempColor.b = mix(tempColor.b,texture2D( inputImageTexture5, vec2(temp.b,tempColor.b)).b, temp.a);
    
    temp = texture2D(inputImageTexture6, texcoordOut2);
    temp.r=temp.r/temp.a;
    temp.g=temp.g/temp.a;
    temp.b=temp.b/temp.a;
    tempColor.r = mix(tempColor.r,texture2D( inputImageTexture7, vec2(temp.r,tempColor.r)).r, temp.a);
    tempColor.g = mix(tempColor.g,texture2D( inputImageTexture7, vec2(temp.g,tempColor.g)).g, temp.a);
    tempColor.b = mix(tempColor.b,texture2D( inputImageTexture7, vec2(temp.b,tempColor.b)).b, temp.a);
    
//    gl_FragColor = mix(srcColor,tempColor,alpha);
    gl_FragColor = tempColor;
}
