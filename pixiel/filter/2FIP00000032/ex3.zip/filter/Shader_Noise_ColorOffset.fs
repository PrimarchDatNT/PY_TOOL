precision highp float;
varying vec2 vTexcoord;
varying vec2 vEffectCoord;
uniform sampler2D inputImageTexture0;
uniform float shift;
uniform float effectStartDistance;
uniform vec2 effectCenter;
uniform vec2 distanceFieldCorrectionVector;

uniform float textureWidth;
uniform float textureHeight;
//uniform int textureIndex;

varying float vTextureIndex;

uniform float alpha;

//uniform int kSamplesNum;//偏色的循环值
const int kSamplesNum = 5;
const float kRedShiftFactor = 1.0;
const float kBlueShiftFactor = 2.0;
const float kGreenShiftFactor = 1.5;
const  float kEpsilon = 0.000001;
const  vec2 effectTranslation = vec2(0.0, 0.0);

const int iter = 2;
//uniform int iter;//噪点的循环值

float hash12(vec2 p)
{
	vec3 p3  = fract(vec3(p.xyx) * 0.1031);
    p3 += dot(p3, p3.yzx + 19.19);
    return fract((p3.x + p3.y) * p3.z);
}

float lag_noise(vec2 p){
	float a = 0.0;
    for (int t = 0; t < iter; t++)
    {
        float v = float(t + 1)*1.5;
        vec2 pos = (p * v + vTextureIndex * 10.0);
        a += hash12(pos);
    }
    return a / float(iter);
}

void main() {
   vec3 sourceTexcoord = vec3(vTexcoord, 1.0);
   vec2 projectedSourceTexCoord = sourceTexcoord.xy / sourceTexcoord.z;
    float insideSourceBounds = float((all(greaterThanEqual(projectedSourceTexCoord, vec2(0.0))) && all(lessThanEqual(projectedSourceTexCoord, vec2(1.0)))));
    vec4 originalColor = float(insideSourceBounds) * texture2D(inputImageTexture0, projectedSourceTexCoord);
     vec3 outputColor = originalColor.rgb;
	//lowp vec3 outputColor = vec3(1.0,1.0,0.0);
    vec2 vecFromCenter = max(vec2(0.0), abs(vEffectCoord) - distanceFieldCorrectionVector);
    float vecFromCenterLength = length(vecFromCenter);
    float distFromCenter = max(0.0, vecFromCenterLength - effectStartDistance);
	if (dot(shift, shift) > 0.0) {
		vecFromCenter = normalize((vTexcoord - effectTranslation - effectCenter));
		distFromCenter = max(0.0, vecFromCenterLength - effectStartDistance) / (1.0 - effectStartDistance + kEpsilon);
	    float rangeLength = shift * distFromCenter;
		vec2 range = vecFromCenter * rangeLength;
	    vec2 redShift = range * kRedShiftFactor;
	    vec2 greenShift = range * kGreenShiftFactor;
		vec2 blueShift = range * kBlueShiftFactor;
		vec2 samplingStep = range / vec2(kSamplesNum);
		vec3 accumulator = vec3(0);
		for (int i = 0; i < kSamplesNum; ++i) {
			accumulator.r += texture2D(inputImageTexture0, vTexcoord - redShift).r;
			redShift += samplingStep;
			accumulator.g += texture2D(inputImageTexture0, vTexcoord - greenShift).g;
			greenShift += samplingStep;
			accumulator.b += texture2D(inputImageTexture0, vTexcoord - blueShift).b;
			blueShift += samplingStep;
		}
		outputColor = accumulator / vec3(kSamplesNum);
	}
	vec4 srcColor = vec4(outputColor,1.0);
	//vec4 srcColor = texture2D(inputImageTexture0,vTexcoord);

	float noiseGray = lag_noise(vTexcoord*vec2(textureWidth,textureHeight));
	//float noiseGray = n8rand(texcoordOut);
	vec3 noiseColor = vec3(noiseGray);
	vec4 lutColor;

	if(noiseGray<0.5) lutColor.rgb = noiseColor*srcColor.rgb/0.5+(vec3(1.0)-2.0*noiseColor)*srcColor.rgb*srcColor.rgb;
	else lutColor.rgb = (vec3(1.0)-noiseColor)*srcColor.rgb/0.5+(2.0*noiseColor-vec3(1.0))*sqrt(srcColor.rgb);

	lutColor.a = 1.0;

	vec4 temp = vec4(mix(srcColor.rgb, lutColor.rgb, alpha), 1.0);
	gl_FragColor = temp;
	//gl_FragColor = vec4(noiseColor,1.0);
}
