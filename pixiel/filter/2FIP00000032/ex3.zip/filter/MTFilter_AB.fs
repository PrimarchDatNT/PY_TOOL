#ifdef GL_ES//for discriminate GLES & GL
#ifdef GL_FRAGMENT_PRECISION_HIGH
precision highp float;
#else
precision mediump float;
#endif
#else
#define highp
#define mediump
#define lowp
#endif

uniform sampler2D inputImageTexture0;
uniform sampler2D inputImageTexture1;
uniform sampler2D inputImageTexture2;
uniform sampler2D inputImageTexture3;

varying vec2 texcoordOut;
varying vec2 texcoordOut2;
uniform float alpha;

void main()
{
    vec4 srcColor = texture2D(inputImageTexture0, texcoordOut);
    vec4 tempColor = texture2D(inputImageTexture1, texcoordOut);
    
    tempColor = mix(srcColor,tempColor,alpha);
    
    vec4 temp = texture2D(inputImageTexture2, texcoordOut2);
    temp.r=temp.r/temp.a;
    temp.g=temp.g/temp.a;
    temp.b=temp.b/temp.a;
    tempColor.r = mix(tempColor.r,texture2D( inputImageTexture3, vec2(temp.r,tempColor.r)).r, temp.a);
    tempColor.g = mix(tempColor.g,texture2D( inputImageTexture3, vec2(temp.g,tempColor.g)).g, temp.a);
    tempColor.b = mix(tempColor.b,texture2D( inputImageTexture3, vec2(temp.b,tempColor.b)).b, temp.a);
    
//    gl_FragColor = mix(srcColor,tempColor,alpha);
    gl_FragColor = tempColor;
}
