#ifdef GL_ES
precision highp  float;
#else
#define highp
#define mediump
#define lowp
#endif
uniform sampler2D inputImageTexture0;

varying vec2 texcoordOut;
varying vec2 texcoordOffset[8];
vec4 gauss()
{
    vec4 sum = vec4(0.0);
    sum += texture2D(inputImageTexture0, texcoordOffset[0]) * 0.05;
    sum += texture2D(inputImageTexture0, texcoordOffset[1]) * 0.09;
    sum += texture2D(inputImageTexture0, texcoordOffset[2]) * 0.12;
    sum += texture2D(inputImageTexture0, texcoordOffset[3]) * 0.15;
    sum += texture2D(inputImageTexture0, texcoordOut) * 0.18;
    sum += texture2D(inputImageTexture0, texcoordOffset[4]) * 0.15;
    sum += texture2D(inputImageTexture0, texcoordOffset[5]) * 0.12;
    sum += texture2D(inputImageTexture0, texcoordOffset[6]) * 0.09;
    sum += texture2D(inputImageTexture0, texcoordOffset[7]) * 0.05;
    return sum;
}


void main()
{
    gl_FragColor = gauss();
}


