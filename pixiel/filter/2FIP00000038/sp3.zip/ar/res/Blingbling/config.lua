--当前为新版 bling 算法,依据高光点连通域判断 bling位置,连通域越大 bling 越大
local config = {}
--bling 位置密度属性控制
config.domainsize = 5 --高光点所在位置区域大小(1-100) ps: 设定的区域越大点越少,保留的bling越大(1-100)
config.density=0.9 --高光点所在位置区域亮度 ps:要求的亮度越大点越少(仅在高于设定亮度的区域出现 bling)(尽量不调整)

--bling 效果相关控制
----大小角度控制
config.size=0.2  --整体星星大小控制(0.1-10.0)
config.sizelimit =25 --设置多小范围为小星星(20-50)
config.littlesize =25 --设置小星星大小(判断为小于 sizelimit 的星星都会变成这个大小)
config.degree= 0 --素材旋转角(0-360)


config.blur = 0 --bling 素材是否需要模糊(1模糊,0不模糊)
config.faceMask = 2 --是否进行脸部遮罩(0:不进行遮罩,1遮罩小星星,2遮罩全部星星)

----高光控制
config.highlightAlpha=0.5 --星星高光亮度

----星星色彩控制
config.useColor=0 --是否需要识别颜色(1识别颜色选择 bling 素材,0不使用颜色识别)
config.useMaterialColor=0 --是否使用素材调整颜色(1使用颜色素材,0不使用颜色素材)
config.starlight=0.9 --彩色星星亮度
config.saturation= 1.0 --色彩饱和度
config.blendmode= 2 --1:线性光叠加 2:滤色
config.touchcontrol=1 --是否需要开启触摸控制颜色改变

--对原图处理
config.lut = 0 --原图是否需要基准图调色(1调色,0不调色)
config.srcblur=0 --开启原图模糊,星星变少变稳定
config.blursize=3 
config.blurtime=1 --调整星星稳定度



--分布阈值
-- config.thr={0,140,181,255} --分布较均匀(新版)
config.thr={0,140,255}    --分布较密集(老版)

--性能控制
config.maxLength=720 --计算时缩放的图片最长边大小
    

return config