local config = {}

-- mask模糊半径
config.blurRadius = 6.0

--背景模糊半径
config.blurRadius2 = 3.0

--脸部不模糊程度
config.faceAlpha = 0.6

--最多人脸数
config.maxFaceCount = 4

--buffer大小
config.maxSize = 750

--滤色程度
config.screenAlpha = 0.5

--柔光程度
config.softAlpha = 1.5

--滤色柔光混合程度（越大滤色成分越大）
config.mixAlpha = 0.8

--脸部提亮程度
config.faceBrightAlpha = 0.7

return config