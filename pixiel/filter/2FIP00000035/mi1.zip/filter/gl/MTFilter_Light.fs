#ifdef GL_ES//for discriminate GLES & GL
#ifdef GL_FRAGMENT_PRECISION_HIGH
precision highp float;
#else
precision mediump float;
#endif
#else
#define highp
#define mediump
#define lowp
#endif
varying vec2 texcoordOut;
uniform sampler2D inputImageTexture0;
uniform sampler2D inputImageTexture1;
uniform sampler2D inputImageTexture2;
uniform float lightAlpha;
uniform float gsAlpha;
uniform float tempalpha;

float blendScreen(float base, float blend) {
    return 1.0-((1.0-base)*(1.0-blend));
}

vec4 blendScreen(vec4 base, vec4 blend) {
    return vec4(blendScreen(base.r,blend.r),blendScreen(base.g,blend.g),blendScreen(base.b,blend.b),base.a);
}

lowp vec4 lut3d(highp vec4 textureColor)
{
    mediump float blueColor = textureColor.b * 15.0;
    mediump vec2 quad1;
    quad1.y = max(min(4.0,floor(floor(blueColor) * 0.25)),0.0);
    quad1.x = max(min(4.0,floor(blueColor) - (quad1.y * 4.0)),0.0);
    
    mediump vec2 quad2;
    quad2.y = max(min(floor(ceil(blueColor) * 0.25),4.0),0.0);
    quad2.x = max(min(ceil(blueColor) - (quad2.y * 4.0),4.0),0.0);
    
    highp vec2 texPos1;
    texPos1.x = (quad1.x * 0.25) + 0.0078125 + ((0.234375) * textureColor.r);
    texPos1.y = (quad1.y * 0.25) + 0.0078125 + ((0.234375) * textureColor.g);
    
    highp vec2 texPos2;
    texPos2.x = (quad2.x * 0.25) + 0.0078125 + ((0.234375) * textureColor.r);
    texPos2.y = (quad2.y * 0.25) + 0.0078125 + ((0.234375) * textureColor.g);
    
    lowp vec4 newColor1 = texture2D(inputImageTexture2, texPos1);
    lowp vec4 newColor2 = texture2D(inputImageTexture2, texPos2);
    
    mediump vec4 newColor = mix(newColor1, newColor2, fract(blueColor));
    
    return newColor;
}

void main(void)
{
    vec4 centerColor = texture2D(inputImageTexture0,texcoordOut);
    centerColor = lut3d(centerColor);
    vec4 blurColor = texture2D(inputImageTexture1,texcoordOut);
//    float maskVal = blurColor.a*0.457;
    float maskVal = blurColor.a*gsAlpha;
    //blurColor = vec4(blurColor.a);
    blurColor.a =1.0;
    vec4 result = mix(centerColor,blurColor,1.0-maskVal);
    
    vec4 blendColor = result;
    vec4 baseColor = centerColor;
    //result = blendScreen(baseColor,blendColor);
    result = mix(blendScreen(baseColor,blendColor),result,lightAlpha);
    result = mix(result,centerColor,tempalpha);
    
    gl_FragColor = result;
//    gl_FragColor = mix(centerColor, result, alpha);
    //gl_FragColor.a = centerColor.a;
//    gl_FragColor = blurColor;
}

